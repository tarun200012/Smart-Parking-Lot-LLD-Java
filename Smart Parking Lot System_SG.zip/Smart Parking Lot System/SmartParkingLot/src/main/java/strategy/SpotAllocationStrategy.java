package strategy;

import model.Floor;
import model.ParkingSpot;
import model.Vehicle;

public interface SpotAllocationStrategy {
    ParkingSpot allocateSpot(Vehicle vehicle, Floor[] floors);
}
