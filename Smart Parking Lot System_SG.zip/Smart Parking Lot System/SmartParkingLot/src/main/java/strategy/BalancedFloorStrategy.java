package strategy;

import model.*;
import java.util.*;

/**
This class implements the SpotAllocationStrategy.It tries to distribute parked vehicles evenly across all floors.
 */
public class BalancedFloorStrategy implements SpotAllocationStrategy {

    @Override
    public ParkingSpot allocateSpot(Vehicle vehicle, Floor[] floors) {
        SpotType type = getSpotType(vehicle.getType()); // Find the type of spot the vehicle needs

        // Convert floors to a list and sort them based on how many spots of this type are available.
        // This helps in balancing the load (vehicles) across floors.
        List<Floor> sorted = new ArrayList<>(Arrays.asList(floors));
        sorted.sort(Comparator.comparingInt(f -> f.getAvailableSpots(type).size()));

        // Loop through each floor and find the first available spot of the required type
        for (Floor floor : sorted) {
            for (ParkingSpot spot : floor.getAvailableSpots(type)) {
                return spot; // Return the first available suitable spot
            }
        }

        // If no spot is found, return null (means parking is full for this type)
        return null;
    }

    /**
     * This method matches vehicle types with the correct spot size.
     * MOTORCYCLE -> SMALL spot
     * CAR -> MEDIUM spot
     * BUS -> LARGE spot
     */
    private SpotType getSpotType(VehicleType type) {
        switch (type) {
            case MOTORCYCLE:
                return SpotType.SMALL;
            case CAR:
                return SpotType.MEDIUM;
            case BUS:
                return SpotType.LARGE;
            default:
                throw new IllegalArgumentException("Invalid vehicle type");
        }
    }
}
