package strategy;

import model.Floor;
import model.ParkingSpot;
import model.SpotType;
import model.Vehicle;
import model.VehicleType;

/**
This strategy finds the nearest available parking spot for the vehicle.It checks floors in order and picks the first suitable spot it finds.
 */
public class NearestFirstStrategy implements SpotAllocationStrategy {

    @Override
    public ParkingSpot allocateSpot(Vehicle vehicle, Floor[] floors) {
        SpotType desiredType = getSpotType(vehicle.getType()); // Get the spot type based on the vehicle

        // Go through each floor one by one
        for (Floor floor : floors) {
            // Check each available spot on that floor
            for (ParkingSpot spot : floor.getAvailableSpots(desiredType)) {
                return spot; // Return the first matching spot found
            }
        }

        // If no spot found on any floor, return null (no space available)
        return null;
    }

    /**
     * This method maps the type of vehicle to the size of spot it needs:
     * - Motorcycle needs a SMALL spot
     * - Car needs a MEDIUM spot
     * - Bus needs a LARGE spot
     */
    private SpotType getSpotType(VehicleType type) {
        switch (type) {
            case MOTORCYCLE:
                return SpotType.SMALL;
            case CAR:
                return SpotType.MEDIUM;
            case BUS:
                return SpotType.LARGE;
            default:
                throw new IllegalArgumentException("Invalid vehicle type");
        }
    }
}
