import model.*;
import strategy.*;
import java.util.Scanner;
import core.ParkingLotManager;

public class Main {
    public static void main(String[] args) {
        // Create a ParkingLotManager with 3 floors and 5 spots of each type per floor
        // Using BalancedFloorStrategy for allocating spots
        ParkingLotManager manager = new ParkingLotManager(
                3, 5, 5, 5, new BalancedFloorStrategy()
        );

        Scanner scanner = new Scanner(System.in);  
        boolean running = true;  

        // Keep running the menu until the user chooses to exit
        while (running) {
            // Show menu to user
            System.out.println("\n======= Smart Parking System =======");
            System.out.println("1. Vehicle Entry");
            System.out.println("2. Vehicle Exit");
            System.out.println("3. Show Available Spots");
            System.out.println("4. Show Fee Summary");
            System.out.println("5. Exit Program");
            System.out.print("👉 Choose an option: ");

            int choice = scanner.nextInt();  // Take the choice from user
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    // Vehicle is entering
                    System.out.print("Enter vehicle number: ");
                    String number = scanner.nextLine().toUpperCase();

                    System.out.print("Enter vehicle type (MOTORCYCLE, CAR, BUS): ");
                    String typeStr = scanner.nextLine().toUpperCase();
                    try {
                        // Convert entered string to enum
                        VehicleType type = VehicleType.valueOf(typeStr);
                        // Ask parking manager to check in the vehicle
                        manager.checkIn(new Vehicle(number, type));
                    } catch (IllegalArgumentException e) {
                        // If user enters wrong vehicle type
                        System.out.println("Invalid vehicle type. Try again.");
                    }
                    break;

                case 2:
                    // Vehicle is exiting
                    System.out.print("Enter vehicle number: ");
                    String numberPlate = scanner.nextLine().toUpperCase();
                    // Ask manager to check out the vehicle
                    manager.checkOut(numberPlate);
                    break;

                case 3:
                    // Show how many spots are free on each floor
                    manager.displayAvailableSpots();
                    break;

                case 4:
                    // Show how much money has been collected from exited vehicles
                    manager.printFeeSummary();
                    break;

                case 5:
                    // Exit the app after printing final summary
                    manager.printFeeSummary();
                    System.out.println("Goodbye!");
                    running = false;
                    break;

                default:
                    // Invalid option entered
                    System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close(); 
    }
}
