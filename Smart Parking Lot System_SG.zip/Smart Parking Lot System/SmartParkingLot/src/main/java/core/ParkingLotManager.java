package core;

import java.util.HashMap;
import java.util.Map;

import model.Floor;
import model.ParkingSpot;
import model.SpotType;
import model.Ticket;
import model.Vehicle;
import strategy.SpotAllocationStrategy;
import util.FeeCalculator;

/**
This is the main class that manages the parking lot.
It handles vehicle entry, exit, spot allocation, fee calculation, and reporting.
 */
public class ParkingLotManager {
    private final Floor[] floors; // All floors in the parking lot
    private final Map<String, Ticket> activeTickets = new HashMap<>(); // Tracks vehicles currently parked (number plate -> Ticket)
    private final Map<String, Double> feeSummary = new HashMap<>(); // Stores parking fees after checkout (number plate -> fee)
    private final SpotAllocationStrategy strategy; // Strategy to choose how to allocate spots (e.g., nearest or balanced)

    public ParkingLotManager(int floorCount, int small, int medium, int large, SpotAllocationStrategy strategy) {
        this.floors = new Floor[floorCount];
        this.strategy = strategy;

        int spotId = 1;
        for (int i = 0; i < floorCount; i++) {
            floors[i] = new Floor(i + 1);
            for (int j = 0; j < small; j++) floors[i].addSpot(new ParkingSpot(spotId++, i + 1, SpotType.SMALL));
            for (int j = 0; j < medium; j++) floors[i].addSpot(new ParkingSpot(spotId++, i + 1, SpotType.MEDIUM));
            for (int j = 0; j < large; j++) floors[i].addSpot(new ParkingSpot(spotId++, i + 1, SpotType.LARGE));
        }
    }

    /**
     * Method to check-in a vehicle.
     * It finds a free spot, assigns it, and generates a ticket.
     */
    public synchronized void checkIn(Vehicle vehicle) {
        // If vehicle is already parked, don't allow again
        if (activeTickets.containsKey(vehicle.getNumberPlate())) {
            System.out.println("Already checked in");
            return;
        }

        // Ask the strategy to find a suitable spot
        ParkingSpot spot = strategy.allocateSpot(vehicle, floors);
        if (spot == null) {
            System.out.println("No available spot");
            return;
        }

        spot.occupy(); // Mark spot as occupied
        Ticket ticket = new Ticket(vehicle, spot); // Create a new ticket
        activeTickets.put(vehicle.getNumberPlate(), ticket); // Store ticket with vehicle number
        System.out.println("Allocated: " + spot + " to " + vehicle.getNumberPlate());
    }

    /**
     * Method to check out a vehicle.
     * It calculates how long the vehicle was parked and how much fee to charge.
     */
    public synchronized void checkOut(String numberPlate) {
        // Get and remove the active ticket for this vehicle
        Ticket ticket = activeTickets.remove(numberPlate);
        if (ticket == null) {
            System.out.println("No ticket found.");
            return;
        }

        ticket.setExitTime(); // Set current time as exit time
        ticket.getSpot().vacate(); // Mark spot as free

        long seconds = ticket.getSecondsParked(); // Time parked in seconds
        double fee = FeeCalculator.calculateFee(ticket.getVehicle(), seconds); // Calculate fee
        feeSummary.put(numberPlate, fee); // Save fee for summary

        System.out.println("Vehicle " + numberPlate + " exited after " + seconds + " sec. Fee: ₹" + fee);
    }

    /**
     * Shows available parking spots on each floor for each type (SMALL, MEDIUM, LARGE)
     */
    public void displayAvailableSpots() {
        for (Floor floor : floors) {
            System.out.println("📍 Floor " + floor.getFloorNumber() + ":");
            for (SpotType type : SpotType.values()) {
                long count = floor.getAvailableSpots(type).size();
                System.out.println("  - " + type + ": " + count + " spots");
            }
        }
    }

    /**
     * Shows a summary of all vehicles that have exited and how much they paid
     */
    public void printFeeSummary() {
        System.out.println("\n Fee Summary:");
        if (feeSummary.isEmpty()) {
            System.out.println("No vehicles exited yet.");
        } else {
            feeSummary.forEach((number, fee) ->
                System.out.println("• " + number + ": ₹" + fee));
        }
    }

    /**
     * Calculates the total money collected from all vehicles
     */
    public double getTotalCollectedFee() {
        return feeSummary.values().stream().mapToDouble(Double::doubleValue).sum();
    }
}
