package model;

// This enum represents the size/type of parking spot available in the parking lot.
public enum SpotType {
    SMALL,   // suitable for MOTORCYCLE
    MEDIUM,  //suitable for CAR
    LARGE    //suitable for BUS
}
