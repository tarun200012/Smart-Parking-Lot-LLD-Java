package model;

/**
 * This class represents a Parking Ticket issued to a vehicle. It keeps track of the vehicle, the parking spot it used, and
 the entry and exit time (in milliseconds).
 */
public class Ticket {
    private final Vehicle vehicle;         
    private final ParkingSpot spot;       
    private final long entryTime;         
    private long exitTime;               

    // When a ticket is created, store the vehicle and spot, and record current time as entry time
    public Ticket(Vehicle vehicle, ParkingSpot spot) {
        this.vehicle = vehicle;
        this.spot = spot;
        this.entryTime = System.currentTimeMillis(); // Current system time when ticket is created
    }

    // Set the exit time to the current system time when vehicle exits
    public void setExitTime() {
        this.exitTime = System.currentTimeMillis();
    }

    // Calculate how long the vehicle was parked (in seconds)
    public long getSecondsParked() {
        return (exitTime - entryTime) / 1000; // Convert from milliseconds to seconds
    }

    // Return the parking spot associated with this ticket
    public ParkingSpot getSpot() {
        return spot;
    }

    // Return the vehicle associated with this ticket
    public Vehicle getVehicle() {
        return vehicle;
    }

    // Return the entry time in milliseconds
    public long getEntryTime() {
        return entryTime;
    }
}
