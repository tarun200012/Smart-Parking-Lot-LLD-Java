package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single floor in the parking lot.
 * Each floor contains multiple parking spots.
 */
public class Floor {
    private final int floorNumber;
    private final List<ParkingSpot> spots = new ArrayList<>(); 

    // Constructor- sets the floor number
    public Floor(int floorNumber) {
        this.floorNumber = floorNumber;
    }

    // Adds a new parking spot to this floor
    public void addSpot(ParkingSpot spot) {
        spots.add(spot);
    }

    /**
     * This method returns a list of available (not occupied) spots
     * of the given type (SMALL, MEDIUM, or LARGE) on this floor.
     */
    public List<ParkingSpot> getAvailableSpots(SpotType type) {
        List<ParkingSpot> available = new ArrayList<>();
        for (ParkingSpot spot : spots) {
            // Check if the spot is of the required type and is free
            if (spot.getType() == type && !spot.isOccupied()) {
                available.add(spot); // Add to list of available spots
            }
        }
        return available; // Return all available spots of the required type
    }

    // Returns the floor number of this floor
    public int getFloorNumber() {
        return floorNumber;
    }
}
