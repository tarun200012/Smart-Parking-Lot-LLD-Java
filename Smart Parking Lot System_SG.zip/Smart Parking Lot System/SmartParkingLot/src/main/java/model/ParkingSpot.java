package model;

/**
 * Represents a parking spot in the parking lot.
 * A spot has an ID, is located on a certain floor, has a type (size),and can either be occupied or vacant.
 */
public class ParkingSpot {
    private final int id;
    private final int floorNumber; 
    private final SpotType type; 
    private boolean occupied;

    // Constructor to create a new parking spot
    public ParkingSpot(int id, int floorNumber, SpotType type) {
        this.id = id;
        this.floorNumber = floorNumber;
        this.type = type;
        this.occupied = false; // By default, spot is empty
    }

    // Returns the spot ID
    public int getId() {
        return id;
    }

    // Returns the floor number this spot is on
    public int getFloorNumber() {
        return floorNumber;
    }

    // Returns the type (size) of the spot
    public SpotType getType() {
        return type;
    }

    // Checks if the spot is occupied
    public boolean isOccupied() {
        return occupied;
    }

    // Mark the spot as occupied
    public void occupy() {
        if (occupied) throw new IllegalStateException("Spot already occupied."); // Error if already taken
        this.occupied = true;
    }

    // Mark the spot as vacant
    public void vacate() {
        if (!occupied) throw new IllegalStateException("Spot already vacant."); // Error if already empty
        this.occupied = false;
    }

    // Returns a simple description of the spot
    @Override
    public String toString() {
        return "Spot[F" + floorNumber + "-ID:" + id + ", Type: " + type + "]";
    }
}
