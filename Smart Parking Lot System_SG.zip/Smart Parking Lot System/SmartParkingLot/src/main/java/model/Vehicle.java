package model;

// This class represents a Vehicle.
public class Vehicle {
    private final String numberPlate;  // Stores the vehicle number, e.g., "UP32 AB1234"
    private final VehicleType type;    // Stores what kind of vehicle it is: MOTORCYCLE, CAR, or BUS

    // Constructor: This is used when we want to create a new vehicle object
    public Vehicle(String numberPlate, VehicleType type) {
        // If number plate is missing or blank, we throw an error to avoid wrong data
        if (numberPlate == null || numberPlate.isEmpty()) {
            throw new IllegalArgumentException("Number plate can't be empty.");
        }

        this.numberPlate = numberPlate; 
        this.type = type;               
    }

    // This method returns the number plate of the vehicle
    public String getNumberPlate() {
        return numberPlate;
    }

    // This method returns the type of the vehicle (CAR, BIKE, or BUS)
    public VehicleType getType() {
        return type;
    }
}
