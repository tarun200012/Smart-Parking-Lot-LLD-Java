package model;
/**
 * This enum simply lists the types of vehicles we support in our parking system.
 * It's like saying: "Only these types of vehicles are allowed to park."
 */
public enum VehicleType {   
    MOTORCYCLE,    
    CAR,       
    BUS  
}
