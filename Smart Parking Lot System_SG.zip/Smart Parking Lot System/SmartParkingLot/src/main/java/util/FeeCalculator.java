package util;

import model.Vehicle;

public class FeeCalculator {
    public static double calculateFee(Vehicle vehicle, long seconds) {
        switch (vehicle.getType()) {
            case MOTORCYCLE:
                return 0.10 * seconds;
            case CAR:
                return 0.20 * seconds;
            case BUS:
                return 0.50 * seconds;
            default:
                return 0;
        }
    }
}
