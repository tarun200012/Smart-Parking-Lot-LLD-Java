
import core.ParkingLotManager;
import model.Vehicle;
import model.VehicleType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import strategy.BalancedFloorStrategy;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingLotManagerTest {

    private ParkingLotManager manager;

    @BeforeEach
    void setUp() {
        manager = new ParkingLotManager(2, 2, 2, 2, new BalancedFloorStrategy());
    }

    @Test
    void testMultipleVehicleEntryAndExitWithFee() throws InterruptedException {
        Vehicle bike1 = new Vehicle("BIKE123", VehicleType.MOTORCYCLE);
        Vehicle car1 = new Vehicle("CAR456", VehicleType.CAR);
        Vehicle bus1 = new Vehicle("BUS789", VehicleType.BUS);

        manager.checkIn(bike1);
        Thread.sleep(1000);
        manager.checkOut("BIKE123");

        manager.checkIn(car1);
        Thread.sleep(1000);
        manager.checkOut("CAR456");

        manager.checkIn(bus1);
        Thread.sleep(1000);
        manager.checkOut("BUS789");

        double totalFee = manager.getTotalCollectedFee();
        assertTrue(totalFee > 0, "Total fee should be greater than 0");
    }

    @Test
    void testConcurrentEntriesAndExitsWithFee() throws InterruptedException {
        Runnable task1 = () -> {
            Vehicle bike = new Vehicle("B1", VehicleType.MOTORCYCLE);
            manager.checkIn(bike);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            manager.checkOut("B1");
        };

        Runnable task2 = () -> {
            Vehicle car = new Vehicle("C1", VehicleType.CAR);
            manager.checkIn(car);
            try {
                Thread.sleep(1200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            manager.checkOut("C1");
        };

        Thread thread1 = new Thread(task1);
        Thread thread2 = new Thread(task2);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();

        double totalFee = manager.getTotalCollectedFee();
        assertTrue(totalFee > 0, "Total fee should be greater than 0 after concurrency test");
    }

    @Test
    void testMixOfOperationsWithValidFee() throws InterruptedException {
        Vehicle v1 = new Vehicle("A1", VehicleType.CAR);
        Vehicle v2 = new Vehicle("A2", VehicleType.CAR);
        Vehicle v3 = new Vehicle("A3", VehicleType.MOTORCYCLE);

        manager.checkIn(v1);
        Thread.sleep(1000);
        manager.checkOut("A1");

        manager.checkIn(v2);
        manager.checkIn(v3);
        Thread.sleep(500);
        manager.checkOut("A2");
        manager.checkOut("A3");

        double totalFee = manager.getTotalCollectedFee();
        assertTrue(totalFee > 0, "Total fee should be greater than 0 after mixed operations");
    }
}
